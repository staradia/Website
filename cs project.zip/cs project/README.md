# Language Learning Web Application

A modern, interactive web application designed to help users learn a new language through various types of lessons and exercises. The application features a clean, user-friendly interface and tracks user progress over time.

## Features

### 1. Multiple Lesson Types
- **Grammar Lessons**: Interactive exercises covering essential grammar rules
- **Vocabulary Lessons**: Word matching exercises to build vocabulary
- **Speaking Practice**: Conversation-based exercises to improve speaking skills

### 2. Progress Tracking
- Daily streak counter
- Total lessons completed
- Words learned counter
- Progress persistence using localStorage

### 3. Interactive Exercises
- Multiple-choice questions for grammar
- Word-meaning matching for vocabulary
- Text input for speaking practice
- Immediate feedback on answers
- Practice pronunciation feature

### 4. User Interface
- Clean, modern design
- Responsive layout for all devices
- Modal-based lesson interface
- Success messages and progress updates
- Login/Logout functionality

## Technical Details

### Technologies Used
- HTML5
- CSS3
- JavaScript (Vanilla)
- Local Storage for data persistence

### Project Structure
```
├── index.html          # Main application page
├── styles.css          # Global styles
├── script.js           # Main application logic
└── README.md          # Project documentation
```

## Getting Started

1. Clone the repository
2. Open `index.html` in a modern web browser
3. Start learning by clicking on any lesson type

## Usage

### Starting a Lesson
1. Click on any lesson type (Grammar, Vocabulary, or Speaking)
2. Complete all exercises in the lesson
3. Receive immediate feedback on your answers
4. Click "Complete Lesson" when all exercises are correct

### Tracking Progress
- Your progress is automatically saved
- View your current streak, completed lessons, and words learned
- Progress persists between sessions

### Practice Speaking
- Type your responses in the speaking exercises
- Get feedback on your answers
- Use the practice button to hear pronunciation

## Contributing

Feel free to submit issues and enhancement requests!

## License

This project is open source.

## Screenshots

### Main Menu

![Main Menu](images/menu.png)

*Personalized learning dashboard with quick access to lessons, progress, and AI assistant.*

### Lessons Page

![Lessons Page](images/lessons.png)

*Choose from grammar, vocabulary, and speaking lessons.*

### Progress Page

![Progress Page](images/progress.png)

*Track your daily streak, lessons completed, and words learned.*

### Lesson Exercise Example

![Lesson Exercise Example](images/exercise.png)

*Interactive exercise with instant feedback.* 