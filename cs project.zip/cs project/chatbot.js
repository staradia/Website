// Main class for handling the basic chatbot functionality
class Chatbot {
    constructor() {
        // Initialize DOM elements for chatbot interface
        this.messages = document.querySelector('.chatbot-messages');
        this.input = document.querySelector('.chatbot-input input');
        this.sendBtn = document.querySelector('.send-btn');
        this.minimizeBtn = document.querySelector('.minimize-btn');
        this.container = document.querySelector('.chatbot-container');
        
        // Set up event listeners for user interactions
        this.setupEventListeners();
    }

    // Set up event listeners for user interactions
    setupEventListeners() {
        // Handle send button click
        this.sendBtn.addEventListener('click', () => this.sendMessage());
        // Handle Enter key press in input field
        this.input.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.sendMessage();
        });
        // Handle minimize button click
        this.minimizeBtn.addEventListener('click', () => this.toggleMinimize());
    }

    // Process and send user message
    sendMessage() {
        const message = this.input.value.trim();
        if (message) {
            // Display user message and clear input
            this.addMessage(message, 'user');
            this.input.value = '';
            // Process the message to generate a response
            this.processUserMessage(message);
        }
    }

    // Add a message to the chat interface
    addMessage(text, sender) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}`;
        messageDiv.textContent = text;
        this.messages.appendChild(messageDiv);
        // Scroll to bottom of chat
        this.messages.scrollTop = this.messages.scrollHeight;
    }

    // Process user message and generate appropriate response
    processUserMessage(message) {
        // Convert message to lowercase for easier matching
        const lowerMessage = message.toLowerCase();
        let response = '';

        // Simple keyword-based response system
        if (lowerMessage.includes('hello') || lowerMessage.includes('hi')) {
            response = 'Hello! How can I help you with your English learning today?';
        } else if (lowerMessage.includes('grammar')) {
            response = 'I can help you with grammar! Would you like to learn about tenses, articles, or something else?';
        } else if (lowerMessage.includes('vocabulary')) {
            response = 'Great! Let\'s expand your vocabulary. What topic would you like to focus on?';
        } else if (lowerMessage.includes('pronunciation')) {
            response = 'Pronunciation is important! Would you like to practice some common words or phrases?';
        } else if (lowerMessage.includes('thank')) {
            response = 'You\'re welcome! Keep up the great work with your English learning!';
        } else {
            response = 'I\'m here to help you learn English. You can ask me about grammar, vocabulary, or pronunciation!';
        }

        // Add a small delay to make the response feel more natural
        setTimeout(() => {
            this.addMessage(response, 'bot');
        }, 500);
    }

    // Toggle chatbot window between minimized and expanded states
    toggleMinimize() {
        const messages = this.messages;
        const input = this.input;
        const sendBtn = this.sendBtn;
        
        if (messages.style.display === 'none') {
            // Expand chatbot
            messages.style.display = 'block';
            input.style.display = 'block';
            sendBtn.style.display = 'block';
            this.minimizeBtn.textContent = '−';
        } else {
            // Minimize chatbot
            messages.style.display = 'none';
            input.style.display = 'none';
            sendBtn.style.display = 'none';
            this.minimizeBtn.textContent = '+';
        }
    }
}

// Initialize chatbot when the page loads
document.addEventListener('DOMContentLoaded', () => {
    new Chatbot();
}); 