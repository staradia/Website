// Main class for handling the AI chatbot functionality
class AIChatbot {
    constructor() {
        // Initialize DOM elements and state variables
        this.messages = document.querySelector('.chatbot-messages');
        this.input = document.querySelector('.chatbot-input input');
        this.sendBtn = document.querySelector('.send-btn');
        this.minimizeBtn = document.querySelector('.minimize-btn');
        this.container = document.querySelector('.chatbot-container');
        this.isProcessing = false;
        
        // OpenAI API key for authentication
        this.API_KEY = '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';
        
        // Set up event listeners for user interactions
        this.setupEventListeners();
    }

    // Set up event listeners for user interactions
    setupEventListeners() {
        // Handle send button click
        this.sendBtn.addEventListener('click', () => this.sendMessage());
        // Handle Enter key press in input field
        this.input.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && !this.isProcessing) this.sendMessage();
        });
        // Handle minimize button click
        this.minimizeBtn.addEventListener('click', () => this.toggleMinimize());
    }

    // Send user message and get AI response
    async sendMessage() {
        const message = this.input.value.trim();
        if (message && !this.isProcessing) {
            // Set processing state to prevent multiple simultaneous requests
            this.isProcessing = true;
            this.addMessage(message, 'user');
            this.input.value = '';
            this.input.disabled = true;
            this.sendBtn.disabled = true;

            try {
                // Get AI response and display it
                const response = await this.getAIResponse(message);
                this.addMessage(response, 'bot');
            } catch (error) {
                console.error('Detailed error:', error);
                this.addMessage('Sorry, I encountered an error. Please try again.', 'bot');
            }

            // Reset processing state and re-enable input
            this.isProcessing = false;
            this.input.disabled = false;
            this.sendBtn.disabled = false;
            this.input.focus();
        }
    }

    // Get response from OpenAI API
    async getAIResponse(message) {
        const API_URL = 'https://api.openai.com/v1/chat/completions';

        try {
            console.log('Sending request to OpenAI...');
            // Make API request to OpenAI
            const response = await fetch(API_URL, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.API_KEY}`
                },
                body: JSON.stringify({
                    model: "gpt-3.5-turbo",
                    messages: [
                        {
                            role: "system",
                            content: "You are a friendly and knowledgeable English language learning assistant. Your goal is to help users improve their English skills through conversation, explanations, and practice. Be encouraging and provide clear, helpful responses."
                        },
                        {
                            role: "user",
                            content: message
                        }
                    ],
                    temperature: 0.7,
                    max_tokens: 150
                })
            });

            // Handle API errors
            if (!response.ok) {
                const errorData = await response.json();
                console.error('API Error Response:', errorData);
                throw new Error(`API request failed: ${response.status} - ${errorData.error?.message || 'Unknown error'}`);
            }

            // Process successful response
            const data = await response.json();
            console.log('API Response:', data);
            return data.choices[0].message.content;
        } catch (error) {
            console.error('API Error:', error);
            throw error;
        }
    }

    // Add a message to the chat interface
    addMessage(text, sender) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}`;
        
        if (sender === 'bot') {
            // Show typing indicator for bot messages
            messageDiv.innerHTML = '<span class="typing-indicator">...</span>';
            this.messages.appendChild(messageDiv);
            this.messages.scrollTop = this.messages.scrollHeight;
            
            // Replace typing indicator with actual message after delay
            setTimeout(() => {
                messageDiv.textContent = text;
                this.messages.scrollTop = this.messages.scrollHeight;
            }, 500);
        } else {
            // Display user message immediately
            messageDiv.textContent = text;
            this.messages.appendChild(messageDiv);
            this.messages.scrollTop = this.messages.scrollHeight;
        }
    }

    // Toggle chatbot window between minimized and expanded states
    toggleMinimize() {
        const messages = this.messages;
        const input = this.input;
        const sendBtn = this.sendBtn;
        
        if (messages.style.display === 'none') {
            // Expand chatbot
            messages.style.display = 'block';
            input.style.display = 'block';
            sendBtn.style.display = 'block';
            this.minimizeBtn.textContent = '−';
        } else {
            // Minimize chatbot
            messages.style.display = 'none';
            input.style.display = 'none';
            sendBtn.style.display = 'none';
            this.minimizeBtn.textContent = '+';
        }
    }
}

// Initialize chatbot when the page loads
document.addEventListener('DOMContentLoaded', () => {
    new AIChatbot();
}); 