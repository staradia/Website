// Track user progress
let userProgress = {
    streak: 0,
    lessonsCompleted: 0,
    wordsLearned: 0,
    lastLogin: null
};

// Make functions globally accessible
window.startLesson = function(lessonType) {
    // Create lesson content based on the lesson type
    let content = '';
    switch(lessonType) {
        case 'grammar':
            content = createGrammarLesson();
            break;
        case 'vocabulary':
            content = createVocabularyLesson();
            break;
        case 'speaking':
            content = createSpeakingLesson();
            break;
    }

    // Create and show lesson modal
    const modal = document.createElement('div');
    modal.className = 'lesson-modal';
    modal.innerHTML = `
        <div class="lesson-content">
            <div class="lesson-header">
                <h2>${lessonType.charAt(0).toUpperCase() + lessonType.slice(1)} Lesson</h2>
                <button class="close-btn" onclick="this.closest('.lesson-modal').remove()">×</button>
            </div>
            <div class="lesson-body">
                ${content}
            </div>
            <div class="lesson-footer">
                <button class="complete-btn" onclick="completeLesson('${lessonType}')" disabled>Complete Lesson</button>
            </div>
        </div>
    `;

    document.body.appendChild(modal);

    // Add event listeners for grammar exercises
    const optionButtons = modal.querySelectorAll('.options button');
    optionButtons.forEach(button => {
        button.addEventListener('click', function() {
            const exercise = this.closest('.exercise');
            const feedback = exercise.querySelector('.feedback');
            
            // Remove highlight from all buttons in this exercise
            exercise.querySelectorAll('button').forEach(btn => {
                btn.classList.remove('selected', 'correct', 'incorrect');
            });
            
            // Add highlight to clicked button
            this.classList.add('selected');
            
            // Check if answer is correct
            if (this.dataset.correct === 'true') {
                this.classList.add('correct');
                feedback.textContent = 'Correct! Well done!';
                feedback.style.backgroundColor = '#d4edda';
                feedback.style.color = '#155724';
            } else {
                this.classList.add('incorrect');
                feedback.textContent = 'Not quite right. Try again!';
                feedback.style.backgroundColor = '#f8d7da';
                feedback.style.color = '#721c24';
            }
            feedback.style.display = 'block';
            
            // Enable complete button if all exercises are correct
            checkAllExercises(modal);
        });
    });

    // Add event listeners for vocabulary exercises
    const meaningSelects = modal.querySelectorAll('.meaning');
    meaningSelects.forEach(select => {
        select.addEventListener('change', function() {
            const exercise = this.closest('.exercise');
            const feedback = exercise.querySelector('.feedback');
            
            if (this.value === 'correct') {
                feedback.textContent = 'Correct! Well done!';
                feedback.style.backgroundColor = '#d4edda';
                feedback.style.color = '#155724';
            } else if (this.value === 'incorrect') {
                feedback.textContent = 'Not quite right. Try again!';
                feedback.style.backgroundColor = '#f8d7da';
                feedback.style.color = '#721c24';
            } else {
                feedback.textContent = '';
                feedback.style.backgroundColor = '';
                feedback.style.color = '';
            }
            feedback.style.display = 'block';
            
            // Enable complete button if all exercises are correct
            checkAllExercises(modal);
        });
    });

    // Add event listeners for speaking exercises
    const responseInputs = modal.querySelectorAll('.response');
    responseInputs.forEach(input => {
        input.addEventListener('input', function() {
            const exercise = this.closest('.exercise');
            const feedback = exercise.querySelector('.feedback');
            const answer = this.value.toLowerCase().trim();
            
            // Common correct responses for each exercise type
            const correctResponses = {
                'greetings': ['i am fine', 'i am good', 'i am well', 'fine', 'good', 'well', 'great', 'doing well', 'doing good'],
                'introductions': ['my name is', 'i am', 'i\'m', 'hi, i\'m', 'hello, i\'m'],
                'directions': ['go straight', 'turn left', 'turn right', 'it\'s on the', 'you can find it'],
                'ordering': ['i would like', 'i\'d like', 'can i have', 'i want', 'i\'ll have'],
                'shopping': ['it costs', 'it\'s', 'the price is', 'it is', 'they are'],
                'plans': ['yes, i would', 'sure', 'that sounds great', 'i\'d love to', 'yes, let\'s'],
                'weather': ['yes, it is', 'it sure is', 'it\'s beautiful', 'it\'s lovely', 'it\'s nice'],
                'help': ['sure', 'of course', 'i\'d be happy to', 'yes, i can', 'i\'ll help you'],
                'suggestions': ['we could', 'how about', 'let\'s', 'why don\'t we', 'we should'],
                'opinions': ['i think', 'in my opinion', 'i believe', 'i feel', 'from my perspective']
            };

            const exerciseType = exercise.querySelector('h3').textContent.toLowerCase();
            let isCorrect = false;

            // Check if the answer matches any of the correct responses
            for (const [type, responses] of Object.entries(correctResponses)) {
                if (exerciseType.includes(type)) {
                    isCorrect = responses.some(response => answer.includes(response));
                    break;
                }
            }

            if (isCorrect) {
                feedback.textContent = 'Good response!';
                feedback.style.backgroundColor = '#d4edda';
                feedback.style.color = '#155724';
                this.style.borderColor = '#28a745';
            } else {
                feedback.textContent = 'Try a more natural response';
                feedback.style.backgroundColor = '#f8d7da';
                feedback.style.color = '#721c24';
                this.style.borderColor = '#dc3545';
            }
            feedback.style.display = 'block';
            
            // Enable complete button if all exercises are correct
            checkAllExercises(modal);
        });
    });

    const practiceButtons = modal.querySelectorAll('.practice-btn');
    practiceButtons.forEach(button => {
        button.addEventListener('click', function() {
            const phrase = this.previousElementSibling.textContent;
            alert(`Practice saying: ${phrase}`);
        });
    });
};

// Make completeLesson function globally accessible
window.completeLesson = function(lessonType) {
    // Update progress
    userProgress.lessonsCompleted++;
    userProgress.wordsLearned += 10; // Add 10 words for completing a lesson
    
    // Save progress
    saveProgress();
    
    // Update progress display
    updateProgressDisplay();
    
    // Show completion message
    const modal = document.querySelector('.lesson-modal');
    if (modal) {
        modal.remove();
    }
    
    // Show success message
    const successMessage = document.createElement('div');
    successMessage.className = 'success-message';
    successMessage.innerHTML = `
        <div class="success-content">
            <h3>Lesson Completed! 🎉</h3>
            <p>Great job! You've completed the ${lessonType} lesson.</p>
            <p>Words learned: +10</p>
            <button onclick="this.parentElement.parentElement.remove()">Continue</button>
        </div>
    `;
    document.body.appendChild(successMessage);
};

// Initialize user progress from localStorage
function initializeProgress() {
    const savedProgress = localStorage.getItem('userProgress');
    if (savedProgress) {
        userProgress = JSON.parse(savedProgress);
    }
    updateProgressDisplay();
}

// Update progress display
function updateProgressDisplay() {
    const streakCount = document.querySelector('.streak-count');
    const lessonsCount = document.querySelector('.lessons-count');
    const wordsCount = document.querySelector('.words-count');

    if (streakCount) streakCount.textContent = `${userProgress.streak} days`;
    if (lessonsCount) lessonsCount.textContent = userProgress.lessonsCompleted;
    if (wordsCount) wordsCount.textContent = userProgress.wordsLearned;
}

// Save progress to localStorage
function saveProgress() {
    localStorage.setItem('userProgress', JSON.stringify(userProgress));
}

// Handle login button
function handleLogin() {
    const loginBtn = document.querySelector('.login-btn');
    if (loginBtn) {
        loginBtn.addEventListener('click', () => {
            const isLoggedIn = loginBtn.textContent === 'Logout';
            if (isLoggedIn) {
                loginBtn.textContent = 'Login';
                alert('Logged out successfully!');
            } else {
                loginBtn.textContent = 'Logout';
                alert('Logged in successfully!');
                // Update streak
                const today = new Date().toDateString();
                if (userProgress.lastLogin !== today) {
                    if (userProgress.lastLogin === new Date(Date.now() - 86400000).toDateString()) {
                        userProgress.streak++;
                    } else {
                        userProgress.streak = 1;
                    }
                    userProgress.lastLogin = today;
                    saveProgress();
                    updateProgressDisplay();
                }
            }
        });
    }
}

// Create grammar lesson content
function createGrammarLesson() {
    return `
        <h2>Basic Grammar</h2>
        
        <div class="exercise">
            <h3>Exercise 1: Present Simple</h3>
            <p>Choose the correct form of the verb:</p>
            <div class="options">
                <button data-correct="true">She plays tennis every Sunday.</button>
                <button data-correct="false">She play tennis every Sunday.</button>
                <button data-correct="false">She playing tennis every Sunday.</button>
            </div>
            <div class="feedback"></div>
        </div>

        <div class="exercise">
            <h3>Exercise 2: Past Simple</h3>
            <p>Select the correct past tense:</p>
            <div class="options">
                <button data-correct="false">I go to the store yesterday.</button>
                <button data-correct="true">I went to the store yesterday.</button>
                <button data-correct="false">I going to the store yesterday.</button>
            </div>
            <div class="feedback"></div>
        </div>

        <div class="exercise">
            <h3>Exercise 3: Present Continuous</h3>
            <p>Choose the correct form:</p>
            <div class="options">
                <button data-correct="false">They is playing football.</button>
                <button data-correct="true">They are playing football.</button>
                <button data-correct="false">They playing football.</button>
            </div>
            <div class="feedback"></div>
        </div>

        <div class="exercise">
            <h3>Exercise 4: Articles</h3>
            <p>Select the correct article:</p>
            <div class="options">
                <button data-correct="true">I saw a cat in the garden.</button>
                <button data-correct="false">I saw an cat in the garden.</button>
                <button data-correct="false">I saw cat in the garden.</button>
            </div>
            <div class="feedback"></div>
        </div>

        <div class="exercise">
            <h3>Exercise 5: Pronouns</h3>
            <p>Choose the correct pronoun:</p>
            <div class="options">
                <button data-correct="true">She gave the book to him.</button>
                <button data-correct="false">She gave the book to he.</button>
                <button data-correct="false">She gave the book to his.</button>
            </div>
            <div class="feedback"></div>
        </div>

        <div class="exercise">
            <h3>Exercise 6: Prepositions</h3>
            <p>Select the correct preposition:</p>
            <div class="options">
                <button data-correct="true">The book is on the table.</button>
                <button data-correct="false">The book is at the table.</button>
                <button data-correct="false">The book is in the table.</button>
            </div>
            <div class="feedback"></div>
        </div>

        <div class="exercise">
            <h3>Exercise 7: Adjectives</h3>
            <p>Choose the correct adjective order:</p>
            <div class="options">
                <button data-correct="true">She has a beautiful red car.</button>
                <button data-correct="false">She has a red beautiful car.</button>
                <button data-correct="false">She has beautiful a red car.</button>
            </div>
            <div class="feedback"></div>
        </div>

        <div class="exercise">
            <h3>Exercise 8: Adverbs</h3>
            <p>Select the correct adverb:</p>
            <div class="options">
                <button data-correct="true">He speaks English fluently.</button>
                <button data-correct="false">He speaks English fluent.</button>
                <button data-correct="false">He speaks English fluency.</button>
            </div>
            <div class="feedback"></div>
        </div>

        <div class="exercise">
            <h3>Exercise 9: Future Simple</h3>
            <p>Choose the correct future tense:</p>
            <div class="options">
                <button data-correct="true">I will visit my parents tomorrow.</button>
                <button data-correct="false">I visiting my parents tomorrow.</button>
                <button data-correct="false">I visit my parents tomorrow.</button>
            </div>
            <div class="feedback"></div>
        </div>

        <div class="exercise">
            <h3>Exercise 10: Modal Verbs</h3>
            <p>Select the correct modal verb:</p>
            <div class="options">
                <button data-correct="true">You should study for the exam.</button>
                <button data-correct="false">You should to study for the exam.</button>
                <button data-correct="false">You should studying for the exam.</button>
            </div>
            <div class="feedback"></div>
        </div>
    `;
}

// Create vocabulary lesson content
function createVocabularyLesson() {
    return `
        <h2>Vocabulary Builder</h2>
        <p>Learn new words and their meanings.</p>
        
        <div class="exercise">
            <h3>Exercise 1: Common Verbs</h3>
            <div class="matching-exercise">
                <div class="word">Run</div>
                <select class="meaning">
                    <option value="">Select meaning</option>
                    <option value="correct">To move quickly on foot</option>
                    <option value="incorrect">To move slowly</option>
                    <option value="incorrect">To stand still</option>
                </select>
                <div class="feedback"></div>
            </div>
        </div>

        <div class="exercise">
            <h3>Exercise 2: Adjectives</h3>
            <div class="matching-exercise">
                <div class="word">Beautiful</div>
                <select class="meaning">
                    <option value="">Select meaning</option>
                    <option value="correct">Very attractive or pleasing</option>
                    <option value="incorrect">Very small</option>
                </select>
                <div class="feedback"></div>
            </div>
        </div>

        <div class="exercise">
            <h3>Exercise 3: Nouns</h3>
            <div class="matching-exercise">
                <div class="word">Book</div>
                <select class="meaning">
                    <option value="">Select meaning</option>
                    <option value="correct">A written or printed work</option>
                    <option value="incorrect">A type of food</option>
                    <option value="incorrect">A musical instrument</option>
                </select>
                <div class="feedback"></div>
            </div>
        </div>

        <div class="exercise">
            <h3>Exercise 4: Adverbs</h3>
            <div class="matching-exercise">
                <div class="word">Quickly</div>
                <select class="meaning">
                    <option value="">Select meaning</option>
                    <option value="correct">At a fast speed</option>
                    <option value="incorrect">At a slow speed</option>
                    <option value="incorrect">At a medium speed</option>
                </select>
                <div class="feedback"></div>
            </div>
        </div>

        <div class="exercise">
            <h3>Exercise 5: Prepositions</h3>
            <div class="matching-exercise">
                <div class="word">Between</div>
                <select class="meaning">
                    <option value="">Select meaning</option>
                    <option value="correct">In the middle of two things</option>
                    <option value="incorrect">On top of something</option>
                    <option value="incorrect">Under something</option>
                </select>
                <div class="feedback"></div>
            </div>
        </div>

        <div class="exercise">
            <h3>Exercise 6: Colors</h3>
            <div class="matching-exercise">
                <div class="word">Blue</div>
                <select class="meaning">
                    <option value="">Select meaning</option>
                    <option value="correct">The color of the sky</option>
                    <option value="incorrect">The color of grass</option>
                    <option value="incorrect">The color of blood</option>
                </select>
                <div class="feedback"></div>
            </div>
        </div>
    `;
}

// Create speaking lesson content
function createSpeakingLesson() {
    return `
        <h2>Speaking Practice</h2>
        <p>Practice your speaking skills with these conversations.</p>
        
        <div class="exercise">
            <h3>Exercise 1: Greetings</h3>
            <p>Complete the conversation:</p>
            <div class="conversation">
                <p>A: Hello! How are you?</p>
                <input type="text" class="response" placeholder="Type your response...">
                <div class="feedback"></div>
            </div>
        </div>

        <div class="exercise">
            <h3>Exercise 2: Introductions</h3>
            <p>Complete the conversation:</p>
            <div class="conversation">
                <p>A: Hi, I'm John. What's your name?</p>
                <input type="text" class="response" placeholder="Type your response...">
                <div class="feedback"></div>
            </div>
        </div>

        <div class="exercise">
            <h3>Exercise 3: Asking for Directions</h3>
            <p>Complete the conversation:</p>
            <div class="conversation">
                <p>A: Excuse me, how do I get to the library?</p>
                <input type="text" class="response" placeholder="Type your response...">
                <div class="feedback"></div>
            </div>
        </div>

        <div class="exercise">
            <h3>Exercise 4: Ordering Food</h3>
            <p>Complete the conversation:</p>
            <div class="conversation">
                <p>A: What would you like to order?</p>
                <input type="text" class="response" placeholder="Type your response...">
                <div class="feedback"></div>
            </div>
        </div>

        <div class="exercise">
            <h3>Exercise 5: Shopping</h3>
            <p>Complete the conversation:</p>
            <div class="conversation">
                <p>A: How much does this shirt cost?</p>
                <input type="text" class="response" placeholder="Type your response...">
                <div class="feedback"></div>
            </div>
        </div>

        <div class="exercise">
            <h3>Exercise 6: Making Plans</h3>
            <p>Complete the conversation:</p>
            <div class="conversation">
                <p>A: Would you like to go to the movies tomorrow?</p>
                <input type="text" class="response" placeholder="Type your response...">
                <div class="feedback"></div>
            </div>
        </div>

        <div class="exercise">
            <h3>Exercise 7: Weather Talk</h3>
            <p>Complete the conversation:</p>
            <div class="conversation">
                <p>A: It's a beautiful day today, isn't it?</p>
                <input type="text" class="response" placeholder="Type your response...">
                <div class="feedback"></div>
            </div>
        </div>

        <div class="exercise">
            <h3>Exercise 8: Asking for Help</h3>
            <p>Complete the conversation:</p>
            <div class="conversation">
                <p>A: Could you help me with this problem?</p>
                <input type="text" class="response" placeholder="Type your response...">
                <div class="feedback"></div>
            </div>
        </div>

        <div class="exercise">
            <h3>Exercise 9: Making Suggestions</h3>
            <p>Complete the conversation:</p>
            <div class="conversation">
                <p>A: What should we do this weekend?</p>
                <input type="text" class="response" placeholder="Type your response...">
                <div class="feedback"></div>
            </div>
        </div>

        <div class="exercise">
            <h3>Exercise 10: Expressing Opinions</h3>
            <p>Complete the conversation:</p>
            <div class="conversation">
                <p>A: What do you think about the new movie?</p>
                <input type="text" class="response" placeholder="Type your response...">
                <div class="feedback"></div>
            </div>
        </div>
    `;
}

// Function to check if all exercises are correct
function checkAllExercises(modal) {
    const completeBtn = modal.querySelector('.complete-btn');
    const feedbacks = modal.querySelectorAll('.feedback');
    const allCorrect = Array.from(feedbacks).every(feedback => 
        feedback.style.backgroundColor === 'rgb(212, 237, 218)'
    );
    completeBtn.disabled = !allCorrect;
}

// Add styles for the lesson modal and success message
function addLessonStyles() {
    const style = document.createElement('style');
    style.textContent = `
        .lesson-modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            display: flex;
            justify-content: center;
            align-items: flex-start;
            z-index: 1000;
            overflow-y: auto;
            padding: 20px;
        }

        .lesson-content {
            background: white;
            width: 90%;
            max-width: 800px;
            border-radius: 12px;
            padding: 2rem;
            margin: 20px auto;
            max-height: 90vh;
            overflow-y: auto;
        }

        .lesson-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            position: sticky;
            top: 0;
            background: white;
            padding: 1rem 0;
            z-index: 1;
        }

        .lesson-body {
            margin-bottom: 1.5rem;
        }

        .lesson-footer {
            text-align: center;
            position: sticky;
            bottom: 0;
            background: white;
            padding: 1rem 0;
            z-index: 1;
        }

        .exercise {
            margin-bottom: 2rem;
            padding: 1rem;
            border: 1px solid #eee;
            border-radius: 8px;
        }

        .options {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .options button {
            padding: 0.8rem;
            border: 2px solid #e5e5e5;
            border-radius: 8px;
            background: white;
            cursor: pointer;
            transition: all 0.2s;
            text-align: left;
        }

        .options button:hover {
            background: #f5f5f5;
        }

        .options button.selected {
            border-color: #58cc02;
        }

        .options button.correct {
            background: #d4edda;
            border-color: #28a745;
            color: #155724;
        }

        .options button.incorrect {
            background: #f8d7da;
            border-color: #dc3545;
            color: #721c24;
        }

        .matching-exercise {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        .matching-exercise select {
            padding: 0.8rem;
            border: 2px solid #e5e5e5;
            border-radius: 8px;
            background: white;
            cursor: pointer;
        }

        .conversation {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        .conversation input {
            padding: 0.8rem;
            border: 2px solid #e5e5e5;
            border-radius: 8px;
            width: 100%;
        }

        .feedback {
            margin-top: 0.5rem;
            padding: 0.8rem;
            border-radius: 8px;
            display: none;
        }

        .complete-btn {
            background-color: #58cc02;
            color: white;
            border: none;
            padding: 1rem 2rem;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.2s;
        }

        .complete-btn:hover {
            background-color: #4caf02;
        }

        .complete-btn:disabled {
            background-color: #ccc;
            cursor: not-allowed;
        }

        .close-btn {
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: #666;
            padding: 0.5rem;
        }

        .close-btn:hover {
            color: #333;
        }

        .success-message {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 2000;
        }

        .success-content {
            background: white;
            padding: 2rem;
            border-radius: 12px;
            text-align: center;
            max-width: 400px;
            width: 90%;
        }

        .success-content h3 {
            color: #28a745;
            margin-bottom: 1rem;
        }

        .success-content button {
            background: #58cc02;
            color: white;
            border: none;
            padding: 0.8rem 2rem;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
            margin-top: 1rem;
        }

        .success-content button:hover {
            background: #4caf02;
        }

        @media (max-width: 768px) {
            .lesson-content {
                width: 95%;
                padding: 1rem;
            }

            .exercise {
                padding: 0.8rem;
            }
        }
    `;
    document.head.appendChild(style);
}

// Initialize everything when the page loads
document.addEventListener('DOMContentLoaded', () => {
    initializeProgress();
    handleLogin();
    addLessonStyles();
}); 